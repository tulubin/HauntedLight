<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="doorAnimate" tilewidth="32" tileheight="32" tilecount="8" columns="4">
 <image source="doorAnimate.png" trans="ff00ff" width="128" height="64"/>
</tileset>
