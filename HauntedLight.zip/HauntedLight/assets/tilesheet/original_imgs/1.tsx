<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="puzzle-1-test" tilewidth="32" tileheight="32" tilecount="100" columns="10">
 <image source="1.png" trans="ff00ff" width="320" height="320"/>
</tileset>
